extern int FIRST_GO_ROUND;

extern bool FAMILY_MODE;
extern bool OUTPUT_TO_FILE;
extern string OUTFILE;
