typedef int bool;

#define TRUE 1
#define FALSE 0

